

## Function List

* [x] User CRUD
* [x] User Export and Import
* [x] User Migrate and Seeder
* [x] User Form Validation
* [x] Laravel DataTables ([yajra](https://github.com/yajra/laravel-datatables))
* [x] Laravel Excel ([Laravel Excel](https://github.com/SpartnerNL/Laravel-Excel))
* [x] Bootstrap 5 ([Bootstrap 5](https://github.com/twbs/bootstrap))
* [x] Fortawesome 6 ([FortAwesome 6](https://github.com/FortAwesome/Font-Awesome))
* [x] DataTables ([DataTables](https://github.com/DataTables/DataTables))
