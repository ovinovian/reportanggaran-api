

<?php $__env->startSection('title', 'Excell'); ?>

<?php $__env->startSection('content'); ?>
<div class="container shadow-sm bg-body rounded py-4">
  <header class="pb-3 mb-4 border-bottom">
    <a href="<?php echo e(route($type . '.index')); ?>" class="d-flex align-items-center text-dark text-decoration-none">
      
      <span class="fs-4"><?php echo $__env->yieldContent('title'); ?></span>
    </a>
  </header>

  <div class="row mb-3">
    <div class="col d-flex justify-content-end">
      <div class="btn-group" role="group" aria-label="Basic outlined example">
        
        <a href="<?php echo e(route($type . '.import')); ?>" class="btn btn-outline-primary text-capitalize">
          <i class="fa-solid fa-file-arrow-up fa-lg me-1"></i>
          <?php echo e(__('Upload')); ?>

        </a>

        

      </div>
    </div>
  </div>

  <div class="row mb-3">
    <div class="col">
      <div class="input-group">
        <input class="form-control" type="text" placeholder="Search" id="search">
        <span class="input-group-text">
          <i class="fa-solid fa-magnifying-glass"></i>
        </span>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col">
      <table id="data-table" class="table table-striped table-hover table-sm">
        <thead>
          <tr>
            <th>No</th>
            
            <th scope="col">Nama SKPD</th>
            
            <th scope="col">Nama Sub SKPD</th>
            
            <th scope="col">Nama Urusan</th>
            
            <th scope="col">Nama Bidang Urusan</th>
            
            <th scope="col">Nama Program</th>
            
            <th scope="col">Nama Kegiatan</th>
            
            <th scope="col">Nama Sub Kegiatan</th>
            
            <th scope="col">Nama Rekening</th>
            
            <th scope="col">Nilai Realisasi</th>
            
            
            
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php if (! $__env->hasRenderedOnce('51c15029-dea9-4325-8d2c-941ddf53cfa3')): $__env->markAsRenderedOnce('51c15029-dea9-4325-8d2c-941ddf53cfa3'); ?>
<?php $__env->startPush('after-style'); ?>
<style>
  .dropdown-toggle::after {
    display: none;
  }

  .dataTables_processing {
    z-index: 11000 !important;
  }
</style>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php if (! $__env->hasRenderedOnce('16411d0d-989e-494e-850c-4fd265437af9')): $__env->markAsRenderedOnce('16411d0d-989e-494e-850c-4fd265437af9'); ?>
<?php $__env->startPush('after-scripts'); ?>
<script>
  $(function() {
      $.fn.DataTable.ext.pager.numbers_length = 5;

      var table = $('#data-table').DataTable({
        ajax: {
          url: "<?php echo e(route($type . '.index')); ?>",
        },
        autoWidth: false,
        columns: [
          {
            name: 'DT_RowIndex',
            data: 'DT_RowIndex',
            orderable: false,
            searchable: false
          },
          // { name: 'kode_skpd', data: 'kode_skpd' },
          { name: 'nama_skpd', data: 'nama_skpd' },
          // { name: 'kode_sub_skpd', data: 'kode_sub_skpd' },
          { name: 'nama_sub_skpd', data: 'nama_sub_skpd' },
          // { name: 'kode_urusan', data: 'kode_urusan' },
          { name: 'nama_urusan', data: 'nama_urusan' },
          // { name: 'kode_bidang_urusan', data: 'kode_bidang_urusan' },
          { name: 'nama_bidang_urusan', data: 'nama_bidang_urusan' },
          // { name: 'kode_program', data: 'kode_program' },
          { name: 'nama_program', data: 'nama_program' },
          // { name: 'kode_kegiatan', data: 'kode_kegiatan' },
          { name: 'nama_kegiatan', data: 'nama_kegiatan' },
          // { name: 'kode_sub_kegiatan', data: 'kode_sub_kegiatan' },
          { name: 'nama_sub_kegiatan', data: 'nama_sub_kegiatan' },
          // { name: 'kode_rekening', data: 'kode_rekening' },
          { name: 'nama_rekening', data: 'nama_rekening' },
          // { name: 'nomor_spd', data: 'nomor_spd' },
          // { name: 'periode_spd', data: 'periode_spd' },
          // { name: 'nilai_detail_spd', data: 'nilai_detail_spd' },
          // { name: 'sisa_detail_spd', data: 'sisa_detail_spd' },
          // { name: 'tahap_spd', data: 'tahap_spd' },
          // { name: 'sub_tahap_spd', data: 'sub_tahap_spd' },
          // { name: 'status_tahap_spd', data: 'status_tahap_spd' },
          // { name: 'dokumen', data: 'dokumen' },
          // { name: 'jenis', data: 'jenis' },
          // { name: 'nomor_dokumen', data: 'nomor_dokumen' },
          // { name: 'nomor_lpj', data: 'nomor_lpj' },
          // { name: 'status_lpj', data: 'status_lpj' },
          // { name: 'tgl_simpan', data: 'tgl_simpan' },
          // { name: 'tgl_dokumen', data: 'tgl_dokumen' },
          // { name: 'bln_dokumen', data: 'bln_dokumen' },
          // { name: 'ket_dokumen', data: 'ket_dokumen' },
          { name: 'nilai_realisasi', data: 'nilai_realisasi' },
          // { name: 'nilai_setoran', data: 'nilai_setoran' },
          // { name: 'user_dokumen', data: 'user_dokumen' },
          // { name: 'pegawai_dokumen', data: 'pegawai_dokumen' },
          // { name: 'nomor_spp', data: 'nomor_spp' },
          // { name: 'tgl_spp', data: 'tgl_spp' },
          // { name: 'nomor_spm', data: 'nomor_spm' },
          // { name: 'tgl_spm', data: 'tgl_spm' },
          // { name: 'nomor_sp2d', data: 'nomor_sp2d' },
          // { name: 'nilai_sp2d', data: 'nilai_sp2d' },
          // { name: 'tgl_sp2d', data: 'tgl_sp2d' },
          // { name: 'periode', data: 'periode' },
          // { name: 'nilai_realisasi_lra', data: 'nilai_realisasi_lra' },
          // { name: 'no_spp_gu', data: 'no_spp_gu' },
          // { name: 'nilai_spp_gu', data: 'nilai_spp_gu' },
        ],
        columnDefs: [
          {
            targets: 'action',
            className: "text-center",
          },
          {
            targets: 'status',
            className: "text-center",
          },
        ],
        deferRender: true,
        dom: "" +
          "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'p>>" +
          "<'row'<'col-sm-12'tr>>" +
          "<'row'<'col-sm-12 col-md-6'i><'col-sm-12 col-md-6'p>>" +
        "",
        fixedHeader: {
          header: true,
        },
        language: {
          decimal: "",
          emptyTable: "No data available in table",
          info: "Showing _START_ to _END_ of _TOTAL_ entries",
          infoEmpty: "Showing 0 to 0 of 0 entries",
          infoFiltered: "(filtered from _MAX_ total entries)",
          infoPostFix: "",
          thousands: ",",
          lengthMenu: "Show _MENU_",
          loadingRecords: "Loading...",
          processing: "",
          search: "",
          searchPlaceholder: "Search",
          zeroRecords: "No matching records found",
          paginate: {
            first: "<i class='fa-solid fa-angles-left'></i>",
            last: "<i class='fa-solid fa-angles-right'></i>",
            next: "<i class='fa-solid fa-angle-right'></i>",
            previous: "<i class='fa-solid fa-angle-left'></i>"
          },
          aria: {
              sortAscending:  ": activate to sort column ascending",
              sortDescending: ": activate to sort column descending"
          }
        },
        lengthChange: true,
        lengthMenu: [
            [5, 10, 25, 50, 100],
            [5, 10, 25, 50, 100],
        ],
        order: [1,'desc'],
        pageLength: 50,
        pagingType: 'full_numbers',
        processing: true,
        responsive: true,
        searching: true,
        serverSide: true,
        select: false,
        buttons: [
          'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        drawCallback: function( settings ) {
          $('[data-bs-toggle="tooltip"]').tooltip({
            container : 'body'
          });
        },
      });

      $('#search').keypress(function(e) {
        table.search($(this).val()).draw();
      });

      table.on('page.dt', function() {
        $('html, body').animate({
            scrollTop: $('#data-table').offset().top
        }, 'fast');
        $('thead tr th:first-child').focus();
        $( "#search" ).focus();
      });

      table.on('click', '.delete-btn[data-id]', function (e) {
        e.preventDefault();
        var id = $(this).attr('id');
        Swal.fire({
          title: 'Are you sure ?',
          icon: 'warning',
          focusConfirm: false,
          showCancelButton: true,
          confirmButtonText: 'Yes',
          cancelButtonText: 'No'
        }).then((result) => {
          if (result.dismiss !== Swal.DismissReason.cancel) {
            $.ajaxSetup({
              headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
            });
            $.ajax({
              url: "user/" + id,
              type: 'DELETE',
              dataType: 'json',
              data: {method: '_DELETE', submit: true},
              success:function(data) {
                Swal.fire(
                  'Deleted!',
                  'Your data has been deleted.',
                  'success'
                )
                table.draw(false);
              },
              error: function(jqXhr, json, errorThrown){
                Swal.fire(
                  'Failed!',
                  'Your data failed to delete.',
                  'error'
                )
              }
            });
          }
        })
      });

      // $('#exportExcel').on('click', function(e) {
      //   table.buttons( '.buttons-excel' ).trigger();
      // });

      // $('#exportPdf').on('click', function(e) {
      //   table.buttons( '.buttons-pdf' ).trigger();
      // });
    });
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\reportanggaran-api\resources\views/anggaran/index.blade.php ENDPATH**/ ?>