<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="description" content="<?php echo e(config('app.name', 'Laravel 9')); ?> | <?php echo $__env->yieldContent('title'); ?>">
    <title><?php echo e(config('app.name', 'Laravel 9')); ?> | <?php echo $__env->yieldContent('title'); ?> </title>

    <!-- favicon -->
    <!-- https://realfavicongenerator.net/ -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('favicon/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon/favicon-16x16.png')); ?>" />
    <link rel="manifest" href="<?php echo e(asset('favicon/site.webmanifest')); ?>" />
    <link rel="mask-icon" href="<?php echo e(asset('favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5" />
    <meta name="msapplication-TileColor" content="#007f00" />
    <meta name="theme-color" content="#ffffff" />

    <?php echo $__env->yieldPushContent('before-style'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <style>
      body {
        background: #f4f6f9;
        font-family: "Nunito",sans-serif;
      }

      .fill-blue {
        filter: invert(34%) sepia(52%) saturate(6351%) hue-rotate(211deg) brightness(101%) contrast(102%);
      }
    </style>
    <?php echo $__env->yieldPushContent('after-style'); ?>
  </head>
  <body>
    <main>
      <?php echo $__env->yieldContent('content'); ?>

      <div class="container">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
          <div class="col-md-4 d-flex align-items-center">
            
          </div>

          <div class="nav col-md-4 justify-content-end list-unstyled d-flex">
            <span class="text-muted">&copy; 2022</span>
          </div>
        </footer>
      </div>

      <?php echo $__env->yieldPushContent('before-scripts'); ?>
      <script src="<?php echo e(mix('js/app.js')); ?>"></script>
      <script>
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
          return new bootstrap.Tooltip(tooltipTriggerEl)
        });
      </script>
      <?php echo $__env->yieldPushContent('after-scripts'); ?>
    </main>
  </body>
</html>
<?php /**PATH G:\laragon\www\reportanggaran-api\resources\views\layouts\default.blade.php ENDPATH**/ ?>