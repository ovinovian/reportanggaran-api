

<?php $__env->startSection('title', __('Datatables CRUD')); ?>

<?php $__env->startSection('content'); ?>
<div class="container shadow-sm bg-body rounded py-4">
  <header class="pb-3 mb-4 border-bottom">
    <a href="<?php echo e(route($type . '.index')); ?>" class="d-flex align-items-center text-dark text-decoration-none">
      <img src="<?php echo e(asset('logo.svg')); ?>" class="me-2 fill-blue" width="50" height="50" alt="<?php echo e(config('app.name', 'Laravel 9')); ?> | <?php echo $__env->yieldContent('title'); ?>">
      <span class="fs-4"><?php echo $__env->yieldContent('title'); ?></span>
    </a>
  </header>

  <div class="row mb-3">
    <div class="col">
      <table class="table table-striped table-bordered table-hover table-sm">
        <tbody>
          <tr>
            <td class="text-capitalize"><?php echo e(__('name')); ?></td>
            <td><?php echo e($data->name); ?></td>
          </tr>
          <tr>
            <td class="text-capitalize"><?php echo e(__('username')); ?></td>
            <td><?php echo e($data->username); ?></td>
          </tr>
          <tr>
            <td class="text-capitalize"><?php echo e(__('phone')); ?></td>
            <td><?php echo e($data->phone); ?></td>
          </tr>
          <tr>
            <td class="text-capitalize"><?php echo e(__('email')); ?></td>
            <td><?php echo e($data->email); ?></td>
          </tr>
          <tr>
            <td class="text-capitalize"><?php echo e(__('status')); ?></td>
            <td>
              <?php if($data->is_active): ?>
                <i class="fa-solid fa-circle-check text-primary me-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Active"></i>
                <?php echo e(__('Active')); ?>

              <?php else: ?>
                <i class="fa-solid fa-lock text-danger me-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Non Active"></i>
                <?php echo e(__('Non Active')); ?>

              <?php endif; ?>
            </td>
          </tr>
        </tbody>
      </table>
      <a href="<?php echo e(route($type . '.index')); ?>" name="cancel" id="cancel" class="btn btn-outline-danger text-uppercase">
        <i class="fa-solid fa-rotate-left me-1"></i>
        <?php echo e(__('back')); ?>

      </a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\reportanggaran-api\resources\views\user\show.blade.php ENDPATH**/ ?>