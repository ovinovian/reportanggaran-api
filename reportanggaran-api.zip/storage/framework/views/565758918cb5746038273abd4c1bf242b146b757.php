

<?php $__env->startSection('title', __('Datatables CRUD - Import Data')); ?>

<?php $__env->startSection('content'); ?>
<div class="container shadow-sm bg-body rounded py-4">
  <header class="pb-3 mb-4 border-bottom">
    <a href="<?php echo e(route($type . '.index')); ?>" class="d-flex align-items-center text-dark text-decoration-none">
      <img src="<?php echo e(asset('logo.svg')); ?>" class="me-2 fill-blue" width="50" height="50"
        alt="<?php echo e(config('app.name', 'Laravel 9')); ?> | <?php echo $__env->yieldContent('title'); ?>">
      <span class="fs-4"><?php echo $__env->yieldContent('title'); ?></span>
    </a>
  </header>

  <div class="row mb-3">
    <div class="col">
      <form method="POST" action="<?php echo e(route($type . '.import')); ?>" id="form-import" class="needs-validation"
        accept-charset="UTF-8" enctype="multipart/form-data" novalidate>
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <label for="file" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('file')); ?></label>
          <div class="col-sm-10">
            <input type="file" name="file" id="file" class="form-control" value=""
              placeholder="<?php echo e(__('Please Enter File')); ?>" required>
            <div class="invalid-feedback" id="fileError">
              ERROR
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-sm-10 offset-sm-2">
            <div class="row">
              <div class="col d-flex justify-content-start">
                <button type="submit" class="btn btn-outline-primary text-uppercase me-2">
                  <i class="fa-solid fa-check me-1"></i>
                  <?php echo e(__('save')); ?>

                </button>

                <a href="<?php echo e(route($type . '.index')); ?>" name="cancel" id="cancel"
                  class="btn btn-outline-danger text-uppercase">
                  <i class="fa-solid fa-x me-1"></i>
                  <?php echo e(__('cancel')); ?>

                </a>
              </div>

              
            </div>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php if (! $__env->hasRenderedOnce('be74c2cf-1cc4-41d8-b1f6-5cd297897b09')): $__env->markAsRenderedOnce('be74c2cf-1cc4-41d8-b1f6-5cd297897b09'); ?>
<?php $__env->startPush('after-scripts'); ?>
<script>
  $(function() {
      $('#form-import').on('submit', function(e) {
        e.preventDefault();
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        var formData = new FormData(this);
        var formURL = $(this).attr("action");

		    $.ajax({
          url: formURL,
			    method: "POST",
			    data: formData,
          contentType: false,
          processData: false,
          beforeSend: function() {
            $("button").attr("disabled",true);

            const onlyInputs = document.querySelectorAll('#form-import input');
            for(var i = 0; i < onlyInputs.length; i++) {
                name = onlyInputs[i].id;
                if (name) {
                  document.getElementById(name).setCustomValidity('');
                }
            }
          },
          complete: function() {
            $("button").attr("disabled",false);
          },
          success:function(data) {
            $("button").attr("disabled",false);
            if (data.success) {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'save successful',
              }).then(function (result) {
                window.location.href = "<?php echo e(route($type . '.index')); ?>";
              })
            }
          },
          error: function(jqXhr, json, errorThrown) {
            $("button").attr("disabled",false);
            var data = jqXhr.responseJSON;
            $.each(data.errors, function(index, value) {
              if (!isNaN(index)) {
                index = 'file';
              }
              $('#'+index+'Error').html(value[0]);
              document.getElementById(index).setCustomValidity(value[0]);
            });
            Swal.fire({
              icon: 'error',
              title: 'Error Validation',
              text: 'Please check your input',
            });
            $('#form-import').addClass('was-validated');
          }
        });
      });
    });
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\reportanggaran-api\resources\views\anggaran\import.blade.php ENDPATH**/ ?>