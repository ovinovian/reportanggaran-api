

<?php $__env->startSection('title', __('Datatables CRUD - Create Data')); ?>

<?php $__env->startSection('content'); ?>
<div class="container shadow-sm bg-body rounded py-4">
  <header class="pb-3 mb-4 border-bottom">
    <a href="<?php echo e(route($type . '.index')); ?>" class="d-flex align-items-center text-dark text-decoration-none">
      <img src="<?php echo e(asset('logo.svg')); ?>" class="me-2 fill-blue" width="50" height="50" alt="<?php echo e(config('app.name', 'Laravel 9')); ?> | <?php echo $__env->yieldContent('title'); ?>">
      <span class="fs-4"><?php echo $__env->yieldContent('title'); ?></span>
    </a>
  </header>

  <div class="row mb-3">
    <div class="col">
      <form method="POST" action="<?php echo e(route($type . '.store')); ?>" id="form-create" class="needs-validation" accept-charset="UTF-8" enctype="multipart/form-data" novalidate>
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <label for="name" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('name')); ?></label>
          <div class="col-sm-10">
            <input type="text" name="name" id="name" class="form-control" value="" placeholder="<?php echo e(__('Please Enter Name')); ?>" required>
            <div class="invalid-feedback" id="nameError">
              ERROR
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="username" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('username')); ?></label>
          <div class="col-sm-10">
            <input type="text" name="username" id="username" class="form-control" value="" placeholder="<?php echo e(__('Please Enter Username')); ?>" required>
            <div class="invalid-feedback" id="usernameError">
              ERROR
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="phone" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('phone')); ?></label>
          <div class="col-sm-10">
            <input type="text" name="phone" id="phone" class="form-control" value="" placeholder="<?php echo e(__('Please Enter Phone')); ?>" required>
            <div class="invalid-feedback" id="phoneError">
              ERROR
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="email" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('email')); ?></label>
          <div class="col-sm-10">
            <input type="email" name="email" id="email" class="form-control" value="" placeholder="<?php echo e(__('Please Enter Email')); ?>" required>
            <div class="invalid-feedback" id="emailError">
              ERROR
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="password" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('password')); ?></label>
          <div class="col-sm-10">
            <div class="input-group has-validation">
              <input type="password" name="password" id="password" class="form-control" value="" placeholder="<?php echo e(__('Please Enter Password')); ?>" required>
              <span class="input-group-text">
                <i class="fa-solid fa-eye showEye"></i>
                <i class="fa-solid fa-eye-slash hideEye" style="display:none;"></i>
              </span>
              <div class="invalid-feedback" id="passwordError">
                ERROR
              </div>
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="password_confirmation" class="col-sm-2 col-form-label text-capitalize"><?php echo e(__('password confirmation')); ?></label>
          <div class="col-sm-10">
            <div class="input-group has-validation">
              <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" value="" placeholder="<?php echo e(__('Please Enter Password Confirmation')); ?>" required>
              <span class="input-group-text">
                <i class="fa-solid fa-eye showEye"></i>
                <i class="fa-solid fa-eye-slash hideEye" style="display:none;"></i>
              </span>
            </div>
          </div>
        </div>

        <fieldset class="row mb-3">
          <legend class="col-form-label col-sm-2 pt-0 text-capitalize"><?php echo e(__('status')); ?></legend>
          <div class="col-sm-10">
            <div class="d-inline-block me-1"><?php echo e(__('Non Active')); ?></div>
            <div class="form-check form-switch d-inline-block">
              <input type="checkbox" class="form-check-input" name="status" id="status" style="cursor: pointer;" checked>
              <label for="status" class="form-check-label"><?php echo e(__('Active')); ?></label>
            </div>
          </div>
        </fieldset>

        <div class="row mb-3">
          <div class="col-sm-10 offset-sm-2">
            <button type="submit" class="btn btn-outline-primary text-uppercase">
              <i class="fa-solid fa-check me-1"></i>
              <?php echo e(__('save')); ?>

            </button>

            <a href="<?php echo e(route($type . '.index')); ?>" name="cancel" id="cancel" class="btn btn-outline-danger text-uppercase">
              <i class="fa-solid fa-x me-1"></i>
              <?php echo e(__('cancel')); ?>

            </a>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php if (! $__env->hasRenderedOnce('8bd2d967-c310-4b89-a615-69c3d727a2f7')): $__env->markAsRenderedOnce('8bd2d967-c310-4b89-a615-69c3d727a2f7'); ?>
  <?php $__env->startPush('after-scripts'); ?>
  <script>
    $(function() {
      $(".showEye").click(passwordShowHide);
      $(".hideEye").click(passwordShowHide);
      function passwordShowHide() {
        var password = $("#password");
        var password2 = $("#password_confirmation");
        var showEye = $(".showEye");
        var hideEye = $(".hideEye");
        if (password.attr('type') === "password") {
          password.prop('type', 'text');
          password2.prop('type', 'text');
          showEye.css("display","none");
          hideEye.css("display","block");
        } else {
          password.prop('type', 'password');
          password2.prop('type', 'password');
          showEye.css("display","block");
          hideEye.css("display","none");
        }
      }

      $('#form-create').on('submit', function(e) {
        e.preventDefault();
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        var formData = new FormData(this);
        var formURL = $(this).attr("action");

		    $.ajax({
          url: formURL,
			    method: "POST",
			    data: formData,
          contentType: false,
          processData: false,
          beforeSend: function() {
            $("button").attr("disabled",true);

            const onlyInputs = document.querySelectorAll('#form-create input');
            for(var i = 0; i < onlyInputs.length; i++) {
                name = onlyInputs[i].id;
                if (name) {
                  document.getElementById(name).setCustomValidity('');
                }
            }
          },
          complete: function() {
            $("button").attr("disabled",false);
          },
          success:function(data) {
            $("button").attr("disabled",false);
            if (data.success) {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'save successful',
              }).then(function (result) {
                window.location.href = "<?php echo e(route($type . '.index')); ?>";
              })
            }
          },
          error: function(jqXhr, json, errorThrown) {
            $("button").attr("disabled",false);
            var data = jqXhr.responseJSON;
            $.each(data.errors, function(index, value) {
              $('#'+index+'Error').html(value);
              document.getElementById(index).setCustomValidity(value);
            });
            Swal.fire({
              icon: 'error',
              title: 'Error Validation',
              text: 'Please check your input',
            });
            $('#form-create').addClass('was-validated');
          }
        });
      });
    });
  </script>
  <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\reportanggaran-api\resources\views\anggaran\create.blade.php ENDPATH**/ ?>